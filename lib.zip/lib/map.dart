import 'package:flutter/material.dart';
//import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() {
  runApp(Mapp());
}

class Mapp extends StatefulWidget {
  @override
  GmapState createState() => GmapState();
}

class GmapState extends State<Mapp> {
  @override
  Widget build(BuildContext context) {
    return Container(
        // child: ,
        );
  }
}
