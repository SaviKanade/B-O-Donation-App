import 'package:cloud_firestore/cloud_firestore.dart';

class Dbdonor {
  final CollectionReference donor =
      FirebaseFirestore.instance.collection("donor");
  Future<void> createUserData(String name, String email, String address,
      String age, String adhar, String uid) async {
    return await donor.doc(uid).set({
      'uid': uid,
      'name': name,
      'email': email,
      'address': address,
      'age': age,
      'adhar': adhar,
    });
  }
}
