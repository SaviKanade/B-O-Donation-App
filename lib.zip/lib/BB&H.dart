import 'package:flutter/material.dart';
import 'dd.dart';

class BBFul extends StatefulWidget {
  @override
  FormState createState() => FormState();
}

class FormState extends State<BBFul> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: Text("DETAILS OF HOSPITALS/BB"),
            backgroundColor: Colors.red),
        resizeToAvoidBottomPadding: false,
        body: new Stack(fit: StackFit.expand, children: <Widget>[
          new Image(
            image: AssetImage("assets/logo.jpg"),
            fit: BoxFit.fill,
            color: Colors.black12,
            colorBlendMode: BlendMode.colorBurn,
          ),
          new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              new Stack(children: <Widget>[
                Container(
                    padding: EdgeInsets.only(top: 40),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                          child: TextField(
                            decoration: InputDecoration(
                                labelText: 'Name of Hospital/Blood Bank -',
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            keyboardType: TextInputType.name,
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                          child: TextField(
                            decoration: InputDecoration(
                                labelText: 'Address of Hospital/Blood Bank -',
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            keyboardType: TextInputType.multiline,
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                          child: TextField(
                            decoration: InputDecoration(
                                labelText: 'Certificate -',
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            keyboardType: TextInputType.multiline,
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                          child: TextField(
                            decoration: InputDecoration(
                                labelText: 'License Number -',
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            keyboardType: TextInputType.number,
                          ),
                        ),
                        SizedBox(height: 30),
                        Container(
                          height: 50,
                          child: MaterialButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Dd()),
                              );
                            },
                            color: Colors.red,
                            highlightColor: Colors.redAccent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(color: Colors.white),
                            ),
                            elevation: 8.0,
                            child: Center(
                              child: Text(
                                'SUBMIT',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
              ])
            ],
          ),
        ]));
  }
}
