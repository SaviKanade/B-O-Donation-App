import 'package:flutter/material.dart';

//import 'dd.dart';

class Seekerf extends StatefulWidget {
  @override
  FormState createState() => FormState();
}

class FormState extends State<Seekerf> {
  /* getAddress() async {
            getCurrentLocation(coordinates);
            var address = await Geocoder.local.findAddressesFromCoordinates();
          }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text("DETAILS OF SEEKER"), backgroundColor: Colors.red),
      resizeToAvoidBottomPadding: false,
      body: new Stack(
        fit: StackFit.expand,
        children: <Widget>[
          new Image(
            image: AssetImage("assets/logo.jpg"),
            fit: BoxFit.fill,
            color: Colors.black12,
            colorBlendMode: BlendMode.colorBurn,
          ),
          new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              new Stack(
                children: <Widget>[
                  Container(
                      padding: EdgeInsets.only(top: 40),
                      child: Column(
                        children: <Widget>[
                          Container(
                            padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                            child: TextField(
                              decoration: InputDecoration(
                                  labelText: 'Name -',
                                  labelStyle: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  )),
                              keyboardType: TextInputType.name,
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                            child: TextField(
                              decoration: InputDecoration(
                                  labelText: 'Address -',
                                  labelStyle: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  )),
                              keyboardType: TextInputType.multiline,
                            ),
                          ),
                          SizedBox(height: 10),
                          Container(
                            padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                            child: TextField(
                              decoration: InputDecoration(
                                  labelText: 'Contact No. -',
                                  labelStyle: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                  )),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          Container(
                              padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    // Text(locationMessage),
                                    FlatButton(
                                        onPressed: () {
                                          // convertCoordinatesToAddress();
                                        },
                                        color: Colors.green,
                                        child: Text("find locaion"))
                                  ])
                              /*decoration: InputDecoration(
                                        labelText: 'Search Available Donor ',
                                        labelStyle: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20,
                                        )),*/
                              //keyboardType: TextInputType.number,
                              ),
                          SizedBox(height: 30),
                          Container(
                            height: 50,
                            child: MaterialButton(
                              onPressed: () async {
                                // await _registerAccount();
                              },
                              color: Colors.red,
                              highlightColor: Colors.redAccent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                side: BorderSide(color: Colors.white),
                              ),
                              elevation: 8.0,
                              child: Center(
                                child: Text(
                                  'SUBMIT',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }
}
