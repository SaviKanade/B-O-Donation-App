import 'package:BOD/appD.dart';
import 'package:flutter/material.dart';
import 'Asa.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'searchH.dart';

class LoginPage extends StatefulWidget {
  State createState() => new LoginPageState();
}

class LoginPageState extends State<LoginPage> {
  bool _secureText = true;

  FirebaseAuth _auth = FirebaseAuth.instance;
  //final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passController = TextEditingController();
  Widget build(BuildContext context) {
    final node = FocusScope.of(context);
    return Scaffold(
        key: _scaffoldkey,
        appBar: AppBar(
            title: Text("BOP"),
            automaticallyImplyLeading: true,
            backgroundColor: Colors.red),
        drawer: ADrawer(),
        resizeToAvoidBottomPadding: false,
        body: new Stack(fit: StackFit.expand, children: <Widget>[
          new Image(
            image: AssetImage("assets/logo.jpg"),
            fit: BoxFit.fill,
            color: Colors.black12,
            colorBlendMode: BlendMode.colorBurn,
          ),
          new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              new Stack(children: <Widget>[
                Container(
                    padding: EdgeInsets.only(top: 70),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 5, 20, 0),
                          child: TextField(
                            controller: _emailController,
                            textInputAction: TextInputAction.next,
                            onEditingComplete: () => node.nextFocus(),
                            decoration: InputDecoration(
                                labelText: 'EmailId -',
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            keyboardType: TextInputType.emailAddress,
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
                          child: TextField(
                            controller: _passController,
                            textInputAction: TextInputAction.next,
                            onSubmitted: (_) => node.unfocus(),
                            decoration: InputDecoration(
                                labelText: 'Password -',
                                suffixIcon: IconButton(
                                  icon: Icon(Icons.remove_red_eye_rounded),
                                  disabledColor: Colors.grey,
                                  onPressed: () {
                                    setState(() {
                                      _secureText = !_secureText;
                                    });
                                  },
                                ),
                                labelStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                )),
                            obscureText: _secureText,
                            keyboardAppearance: Brightness.light,
                          ),
                        ),
                        SizedBox(height: 40),
                        Container(
                          height: 50,
                          child: MaterialButton(
                            onPressed: () async {
                              signInWithEmailAndPassword();
                            },
                            color: Colors.red,
                            highlightColor: Colors.redAccent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(color: Colors.white),
                            ),
                            elevation: 8.0,
                            child: Center(
                              child: Text(
                                'LOGIN',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Asa()),
                                );
                              },
                              child: Text(
                                'New Registration',
                                style: TextStyle(
                                  color: Colors.redAccent,
                                  fontWeight: FontWeight.bold,
                                  decoration: TextDecoration.underline,
                                  textBaseline: TextBaseline.alphabetic,
                                ),
                              ),
                            )
                          ],
                        )
                      ],
                    )),
              ])
            ],
          ),
        ]));
  }

  void signInWithEmailAndPassword() async {
    try {
      final User user = (await _auth.signInWithEmailAndPassword(
              email: _emailController.text, password: _passController.text))
          .user;
      if (!user.emailVerified) {
        await user.sendEmailVerification();
      }
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => SearchH(user: user)));
    } catch (e) {
      _scaffoldkey.currentState
          .showSnackBar(SnackBar(content: Text("Failed To SignIn")));
      print(e);
    }
  }
}
